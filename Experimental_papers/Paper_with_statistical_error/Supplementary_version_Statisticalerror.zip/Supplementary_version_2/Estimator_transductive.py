import numpy as np
from scipy.optimize import minimize


def objective(phi, X, y, lambda_, W):
  """Calculates the objective function of the optimization program.

  Args:
    phi: A numpy array of shape (|W|,) representing the feature interactions.
    X: A numpy array of shape (n, d) representing the feature matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.
    W: A numpy array of shape (|W|,) containing the indices of the elements in the set $\mathcal{W}$.

  Returns:
    A numpy array representing the value of the objective function.
  """

  # Sort the feature interactions in lexicographical order.
  sorted_phi = phi[W]

  # Calculate the squared residual error for each sample.
  squared_residual_error = np.sum((y - sorted_phi)**2)

  # Calculate the regularization term.
  regularization_term = lambda_ * np.sum((sorted_phi - np.mean(sorted_phi))**2)

  # Return the sum of the squared residual error and the regularization term.
  return squared_residual_error + regularization_term


def constraints(phi, W):
  """Calculates the constraints of the optimization program.

  Args:
    phi: A numpy array of shape (|W|,) representing the feature interactions.
    W: A numpy array of shape (|W|,) containing the indices of the elements in the set $\mathcal{W}$.

  Returns:
    A numpy array of shape (|W|,) representing the value of the constraints.
  """

  # Check if the feature interactions are non-decreasing.
  constraints = phi[1:] >= phi[:-1]

  # Return the constraints.
  return constraints


def optimize(X, y, lambda_, W):
  """Solves the optimization program.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.
    W: A numpy array of shape (|W|,) containing the indices of the elements in the set $\mathcal{W}$.

  Returns:
    A numpy array of shape (|W|,) representing the optimal feature interactions.
  """

  # Define the optimization problem.
  def objective_wrapper(phi):
    return objective(phi, X, y, lambda_, W)

  def constraints_wrapper(phi):
    return constraints(phi, W) - 1

  # Define the bounds on the feature interactions.
  bounds = [(None, None)] * len(W)

  # Solve the optimization problem.
  opt = minimize(objective_wrapper, np.ones(len(W)), constraints=constraints_wrapper, bounds=bounds)

  # Return the optimal feature interactions.
  return opt.x


def estimate_phi(X, y, lambda_, W):
  """Estimates the feature interactions using the given data and lambda value.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.
    W: A numpy array of shape (|W|,) containing the indices of the elements in the set $\mathcal{W}$.

  Returns:
    A numpy array of shape (|W|,) representing the estimated feature interactions.
  """

  # Solve the optimization program.
  phi_hat = optimize(X, y, lambda_, W)

  # Return the estimated feature interactions.
  return phi_hat

def compute_w(X, Z):
  """Computes the matrix W from the matrices X and Z.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.

  Returns:
    A numpy array of shape (|W|,) representing the matrix W.
  """

  # Create a temporary matrix W.
  W = np.concatenate((X, Z), axis=1)

  # Sort the rows of W in lexicographical order.
  W = W[W[:, :].argsort(axis=1)]

  # Remove any duplicate rows from W.
  W = W[~np.all(W[:, :-1] == W[:, 1:], axis=1)]

  return W


# Get input X, y, and Z from the user.
X = np.load(input('Enter the path to the X file: '))
y = np.load(input('Enter the path to the y file: '))
Z = np.load(input('Enter the path to the Z file: '))

# Compute the matrix W.
W = compute_w(X, Z)

# Set the lambda parameter.
# IMPORTANT: Instead of asking the user for the value of lambda, one can use 
#"Algorithm 1" in the paper to choose it in a data dependent manner.
lambda_ = float(input('Enter the lambda value: '))

# Estimate the feature interactions.
phi_hat = estimate_phi(X, y, lambda_, W)

# Print the estimated feature interactions.
print(phi_hat)
