import numpy as np
from scipy.optimize import minimize


def objective(beta, X, Z, y):
  """Calculates the objective function of the optimization program.

  Args:
    beta: A numpy array of shape (|Z|,) representing the feature weights.
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.

  Returns:
    A numpy array of shape () representing the value of the objective function.
  """

  # Calculate the predicted values.
  y_hat = np.sum(X * beta[Z], axis=1) / np.sum(beta[Z], axis=1)

  # Calculate the squared residual error for each sample.
  squared_residual_error = np.sum((y - y_hat)**2)

  # Return the squared residual error.
  return squared_residual_error


def constraints(beta):
  """Calculates the constraints of the optimization program.

  Args:
    beta: A numpy array of shape (|Z|,) representing the feature weights.

  Returns:
    A numpy array of shape (|Z|,) representing the value of the constraints.
  """

  # Check if the feature weights are between epsilon and 1.
  constraints_epsilon = beta >= epsilon

  # Check if the feature weights sum to 1.
  constraints_sum = np.sum(beta) == 1

  # Check if the feature weights are non-decreasing.
  constraints_monotonicity = beta[1:] >= beta[:-1]

  # Return the constraints.
  return np.concatenate((constraints_epsilon, constraints_sum, constraints_monotonicity))


def optimize(X, Z, y, epsilon):
  """Solves the optimization program.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.
    epsilon: A float representing the minimum value for the feature weights.

  Returns:
    A numpy array of shape (|Z|,) representing the optimal feature weights.
  """

  # Define the optimization problem.
  def objective_wrapper(beta):
    return objective(beta, X, Z, y)

  def constraints_wrapper(beta):
    return constraints(beta) - 1

  # Define the bounds on the feature weights.
  bounds = [(epsilon, 1)] * len(Z)

  # Solve the optimization problem.
  opt = minimize(objective_wrapper, np.ones(len(Z)), constraints=constraints_wrapper, bounds=bounds)

  # Return the optimal feature weights.
  return opt.x


def estimate_beta(X, Z, y, epsilon):
  """Estimates the feature weights using the given data and epsilon value.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.
    epsilon: A float representing the minimum value for the feature weights.

  Returns:
    A numpy array of shape (|Z|,) representing the estimated feature weights.
  """

  # Solve the optimization program.
  beta_hat = optimize(X, Z, y, epsilon)

  # Return the estimated feature weights.
  return beta_hat


# Get input X, Z, and y from the user.
X = np.load(input('Enter the path to the X file: '))
Z = np.load(input('Enter the path to the Z file: '))
y = np.load(input('Enter the path to the y file: '))
epsilon = 0.0001

# Estimate the feature weights.
beta_hat = estimate_beta(X, Z, y, epsilon)

# Print the estimated feature weights.
print(beta_hat)
