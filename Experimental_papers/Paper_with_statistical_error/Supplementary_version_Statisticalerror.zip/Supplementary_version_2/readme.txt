This package contains code implementing each of the algorithms in the paper "On Aggregating Evaluations with Expertise or Confidence Information".

This code will be made publicly available upon acceptance of the paper.

The package contains five files:

- Estimator_parametric.py: Implements the parametric estimator in equation (4) of the paper. The user can give their inputs of vectors {x_i}s, {z_i}s and labels {y_i}s via files X.npy, Z.npy and y.npy respectively. The user may also change the value of epsilon if they wish.

- Estimator_nonparametric.py: Implements the non-parametric estimator in equation (5) of the paper. The user can give their inputs of vectors {x_i}s, {z_i}s and labels {y_i}s via files X.npy, Z.npy and y.npy respectively. The code fixes lambda=0.1, and this may be replaced with an input from Algorithm 1 in case lambda is chosen in a data-dependent manner. The code outputs the estimate phi_hat.

- Estimator_transductive.py: Implements the non-parametric estimator for transductive setting, speciried in equation (6) of the paper. The user can give their inputs of vectors {x_i}s, {z_i}s and labels {y_i}s via files X.npy, Z.npy and y.npy respectively. The code fixes lambda=0.1, and this may be replaced with an input from Algorithm 1 in case lambda is chosen in a data-dependent manner. The code outputs the estimate phi_hat which is a vector of length |W| and its entries are in order of the entries of set W.

- Algorthm_1.py: Implements "Algorithm 1" from the paper. Takes the gold standard and non-gold standard questions as inputs which can be specified as G.npy and H.npy. The user should replace "solve_eqn_est" with a call to the function that computes either estimator in equation (5) or estimator in equation (6) of the paper. The code outputs the error rate of the algorithm.

- Simulations.py: Implements the simulations described in the paper. The user should replace the mean estimator with the desired estimator. The code returns the error rate.