import pandas as pd
import numpy as np

def transform_to_binary(task, options):
    half_size = len(options) // 2
    group_0 = np.random.choice(options, half_size, replace=False)
    
    return task.apply(lambda x: 0 if x in group_0 else 1)

def impute_skipped_responses(task):
    return task.apply(lambda x: np.random.choice([0, 1]) if x == 'skip' else x)

def error(actual, predicted):
    return np.mean(np.abs(actual - predicted))

def main():
    # IMPORTANT: Give name of file containing the data
    df = pd.read_csv('dataset.csv')
    errors = []

    # Assuming each task has a separate column, iterate over tasks
    for task_name in ['bridge', 'dogs', 'countries', 'flag', 'texture']:
        task = df[task_name]
        
        # Transform tasks to binary
        if task_name != 'bridge':
            unique_options = task.unique()
            task = transform_to_binary(task, unique_options)
        
        # Impute skipped responses
        task = impute_skipped_responses(task)
        
        # Split into gold standard and non-gold standard questions
        gold_standard_indices = np.random.choice(task.index, 15, replace=False)
        gold_standard = task.iloc[gold_standard_indices]
        non_gold_standard = task.drop(gold_standard_indices)
        
        # Process non-gold standard questions
        non_gold_samples = non_gold_standard.sample(3*len(non_gold_standard), replace=True)
        
        # Process gold standard questions
        gold_samples = []
        for index in gold_standard_indices:
            workers = np.where(task.index == index)[0]
            np.random.shuffle(workers)
            
            for i in range(11):
                gold_samples.extend(workers[i*3:(i+1)*3])
        
        gold_samples_tasks = task.iloc[gold_samples]
        
        # IMPORTANT: Replace mean estimator with a call to estimator that is to be evaluated
        estimated_output = np.mean(np.concatenate([non_gold_samples.values, gold_samples_tasks.values]))
        
        # Quantize the output
        estimated_output = 1 if estimated_output > 0.5 else 0
        
        # Measure the error using 0-1 loss
        errors.append(error(gold_standard, estimated_output))
        
    avg_error = np.mean(errors)
    print(f"Average error across tasks: {avg_error}")

if __name__ == "__main__":
    main()
