import numpy as np

def estimate_lambda(G, solve_eqn_est):
  """Estimates the optimal lambda value using the given gold standard questions.

  Args:
    G: A list of gold standard questions.
    solve_eqn_est_transductive: A function that solves the optimization program and returns the optimal feature interactions.

  Returns:
    The optimal lambda value.
  """

  # Set the range of lambda values
  lambda_values = np.concatenate(([0],np.geomspace(2**-16, 2**16, 2**17)))

  # Calculate the error rate for each lambda value.
  error_rates = np.zeros(len(lambda_values))
  for i, lambda_ in enumerate(lambda_values):
    # Solve the optimization program for each gold standard question.
    predictions = []
    for g in G:
      # Solve the optimization program using all gold standard questions except the current one.
      phi_hat = solve_eqn_est_transductive(G - [g], lambda_)

      # Make a prediction for the current gold standard question.
      prediction = phi_hat[g[0], g[1]]
      predictions.append(prediction)

    # Calculate the error rate for the current lambda value.
    error_rates[i] = np.mean(predictions != g[2])

  # Return the optimal lambda value.
  return lambda_values[np.argmin(error_rates)]


def compute_error_rate(H, solve_eqn_est, lambda_):
  """Calculates the error rate on the non-gold standard questions.

  Args:
    H: A list of non-gold standard questions.
    solve_eqn_est_transductive: A function that solves the optimization program and returns the optimal feature interactions.
    lambda_: The lambda value.

  Returns:
    The error rate on the non-gold standard questions.
  """

  #IMPORTANT: Replace this function with a call to either the 
  #transductive or the non-parametric estimator as desired
  #in order to compute phi_hat

  # Solve the optimization program using all gold standard questions.
  phi_hat = solve_eqn_est(G, lambda_)

  # Make predictions for the non-gold standard questions.
  predictions = []
  for h in H:
    prediction = phi_hat[h[0], h[1], h[2]]
    predictions.append(prediction)

  # Calculate the error rate on the non-gold standard questions.
  error_rate = np.mean(predictions != h[3])

  return error_rate


def main():
  # Load the gold standard and non-gold standard questions.
  G = np.load('G.npy')
  H = np.load('H.npy')

  # Estimate the optimal lambda value.
  
  #IMPORTANT: Replace solve_eqn_est with a call to the function that computes either
  #estimator (5) or estimator (6)
  
  lambda_hat = estimate_lambda(G, solve_eqn_est)

  # Calculate the error rate on the non-gold standard questions.
  error_rate = compute_error_rate(H, solve_eqn_est, lambda_hat)

  # Print the error rate.
  print('Error rate:', error_rate)


if __name__ == '__main__':
  main()
