import numpy as np
from numpy import mean

def solve_optimization_program(X, y, lambda_):
  #IMPORTANT: Replace this function with a call to either the 
  #transductive or the non-parametric estimator as desired
  #in order to compute phi_hat

  """
  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.

  Returns:
    A numpy array of shape ((|X| * |Z|)**d,) representing the optimal feature interactions.
  """

  # ...

  return phi_hat

def compute_error_rate(H, phi_hat):
  """Computes the error rate on the non-gold standard questions.

  Args:
    H: A numpy array of shape (n_h,) representing the indices of the non-gold standard questions.
    phi_hat: A numpy array of shape ((|X| * |Z|)**d,) representing the optimal feature interactions.

  Returns:
    A float representing the error rate.
  """

  error_rate = np.mean(phi_hat[H, H] != y[H])

  return error_rate

def run_algorithm(X, y, G, H, lambda_values):
  """Runs the algorithm described in the LaTeX code.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    y: A numpy array of shape (n,) representing the target values.
    G: A numpy array of shape (n_g,) representing the indices of the gold standard questions.
    H: A numpy array of shape (n_h,) representing the indices of the non-gold standard questions.
    lambda_values: A numpy array of floats representing the range of lambda values to try.

  Returns:
    A tuple of two numpy arrays:
      - The first array contains the optimal feature interactions for each lambda value.
      - The second array contains the error rate on the non-gold standard questions for each lambda value.
  """

  phi_hat_values = []
  error_rates = []
  for lambda_ in lambda_values:
    phi_hat = solve_optimization_program(X[G], y[G], lambda_)
    phi_hat_values.append(phi_hat)
    error_rate = compute_error_rate(H, phi_hat)
    error_rates.append(error_rate)

  return np.array(phi_hat_values), np.array(error_rates)

# Load the data
X = np.load('X.npy')
y = np.load('y.npy')
G = np.load('G.npy')
H = np.load('H.npy')

# Set the range of lambda values
lambda_values = np.concatenate(([0],np.geomspace(2**-16, 2**16, 2**17)))

# Run the algorithm
phi_hat_values, error_rates = run_algorithm(X, y, G, H, lambda_values)

# Find the lambda value that minimizes the error rate
best_lambda_index = np.argmin(error_rates)
best_lambda = lambda_values[best_lambda_index]

# Print the best lambda value and the corresponding error rate
print('Best lambda:', best_lambda)
print('Error rate:', error_rates[best_lambda_index])
