import numpy as np
from scipy.optimize import minimize


def objective(phi, X, Z, y, lambda_):
  """Calculates the objective function of the optimization program.

  Args:
    phi: A numpy array representing the feature interactions.
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.

  Returns:
    A numpy array representing the value of the objective function.
  """


  # Calculate the squared residual error for each sample.
  squared_residual_error = np.sum((y -phi)**2)

  # Calculate the regularization term.
  regularization_term = lambda_ * np.sum((phi - np.mean(phi))**2)

  # Return the sum of the squared residual error and the regularization term.
  return squared_residual_error + regularization_term


def constraints(phi):
  """Calculates the constraints of the optimization program.

  Args:
    phi: A numpy array representing the feature interactions.

  Returns:
    A numpy array representing the value of the constraints.
  """

  # Check if the feature interactions are non-decreasing.
  constraints = phi[1:] >= phi[:-1]

  # Check if the feature interactions are symmetric.
  constraints_symmetry = phi == np.roll(phi, 1)

  # Return the constraints.
  return np.concatenate((constraints, constraints_symmetry))


def optimize(X, Z, y, lambda_):
  """Solves the optimization program.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.

  Returns:
    A numpy array representing the optimal feature interactions.
  """
  
  # Initialize
  phi = np.zeros((np.unique(X), np.unique(Z)) * np.size(X, axis=0))

  # Define the optimization problem.
  def objective_wrapper(phi):
    return objective(phi, X, Z, y, lambda_)

  def constraints_wrapper(phi):
    return constraints(phi) - 1

  # Define the bounds on the feature interactions.
  bounds = [(None, None)] * len(phi)

  # Solve the optimization problem.
  opt = minimize(objective_wrapper, np.ones(len(phi)), constraints=constraints_wrapper, bounds=bounds)

  # Return the optimal feature interactions.
  return opt.x


def estimate_phi(X, Z, y, lambda_):
  """Estimates the feature interactions using the given data and lambda value.

  Args:
    X: A numpy array of shape (n, d) representing the feature matrix.
    Z: A numpy array of shape (n, d) representing the context matrix.
    y: A numpy array of shape (n,) representing the target values.
    lambda_: A float representing the regularization parameter.

  Returns:
    A numpy array representing the estimated feature interactions.
  """

  # Solve the optimization program.
  phi_hat = optimize(X, Z, y, lambda_)

  # Return the estimated feature interactions.
  return phi_hat


# Get input X, y, and Z from the user.
X = np.load(input('Enter the path to the X file: '))
Z = np.load(input('Enter the path to the Z file: '))
y = np.load(input('Enter the path to the y file: '))

# IMPORTANT: Instead of asking the user for the value of lambda, one can use 
#"Algorithm 1" in the paper to choose it in a data dependent manner.
lambda_ = float(input('Enter the lambda value: '))

# Estimate the feature interactions.
phi_hat = estimate_phi(X, Z, y, lambda_)

# Print the estimated feature interactions.
print(phi_hat)
